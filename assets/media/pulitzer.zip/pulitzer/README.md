# Pulitzer

This folder contains data behind the story [Do Pulitzers Help Newspapers Keep Readers?](https://fivethirtyeight.com/features/do-pulitzers-help-newspapers-keep-readers/)